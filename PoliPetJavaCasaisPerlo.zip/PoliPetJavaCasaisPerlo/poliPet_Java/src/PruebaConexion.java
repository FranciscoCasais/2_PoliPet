import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class PruebaConexion {
    private Connection conexion;
    private String nombreBD;
    private List<String> lista;

    public Connection getConexion() {
        return conexion;
    }
    public void setConexion(Connection conexion) {
        this.conexion = conexion;
    }
    public String getNombreBD() {
        return nombreBD;
    }
    public void setNombreBD(String nombreBD) {
        this.nombreBD = nombreBD;
    }
    public List<String> getLista() {
        return lista;
    }
    public void setLista(List<String> lista) {
        this.lista = lista;
    }

    public PruebaConexion(String nombreBD, List<String> lista) {
        this.nombreBD = nombreBD;
        this.lista = lista;
    }

    public static void main(String[] args) {
        List<String> lista= (List)( new ArrayList<String> ());
        PruebaConexion p=new PruebaConexion("Nombre", lista);

    }
}
//File
//Project Structure
//Modules
 //Dependencies
   // "+"
