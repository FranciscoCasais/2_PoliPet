import java.time.LocalDate;
public class Vacuna {
    private LocalDate fecha;
    private String dosis;
    public Vacuna() {
        this.fecha=null;
        this.dosis="";
    }
    public Vacuna(LocalDate fecha,String dosis) {
        this.fecha=fecha;
        this.dosis=dosis;
    }
    public LocalDate getFecha() {
        return fecha;
    }
    public String getDosis() {
        return dosis;
    }
    public void setFecha(LocalDate fecha) {
        this.fecha=fecha;
    }
    public void setDosis(String dosis) {
        this.dosis=dosis;
    }
}